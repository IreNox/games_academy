﻿#include "framework.h"

#include <windows.h>

int WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd )
{
	static const ga_graphics_color BackgroundColor = ga_graphics_color_rgb( 0x01u, 0x65u, 0xfcu );

	ga_timer_t* pTimer = ga_timer_create();
	if( !pTimer )
	{
		return 1u;
	}

	ga_graphics_t* pGraphics = ga_graphics_create( 1280, 720, u8"Framework 🚀" );
	if( !pGraphics )
	{
		return 1u;
	}

	ga_input_t* pInput = ga_input_create( pGraphics );
	if( !pInput )
	{
		ga_graphics_destroy( pGraphics );
		return 1u;
	}

	bool running = true;
	while( running )
	{
		const float gameTime = (float)ga_timer_get( pTimer );

		ga_input_update( pInput );

		if( ga_input_was_mouse_button_pressed( pInput, ga_input_mouse_button_left ) )
		{
			running = false;
		}

		ga_graphics_begin_frame( pGraphics );
		ga_graphics_clear( pGraphics, BackgroundColor );
		ga_graphics_end_frame( pGraphics );
	}

	ga_input_destroy( pInput );
	ga_graphics_destroy( pGraphics );
	ga_timer_destroy( pTimer );
	return 0u;
}
